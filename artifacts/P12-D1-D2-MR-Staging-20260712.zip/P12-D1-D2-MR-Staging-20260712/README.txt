P12 D1/D2/MR staging handoff package
Generated: 2026-07-12

Each track contains its archive and required companion files:
  D1/d1-candidates.tar.zst
  D1/d1-candidates.manifest.json
  D1/d1-handoff.json
  D2/d2-candidates.tar.zst
  D2/d2-candidates.manifest.json
  D2/d2-handoff.json
  MR/mr-candidates.tar.zst
  MR/mr-candidates.manifest.json
  MR/mr-handoff.json

Verify before provisioning to P12:
  shasum -a 256 -c SHA256SUMS.txt

Methodological boundary:
- D1 is development/portfolio-construction evidence only, not D2-level paired-revision evidence.
- D2 remains sealed staging input. This package does not authorize opening D2.
- MR is staging input for final admission by main P12's pinned frozen intake.
- This package does not authorize S1/S2 execution, Task 23, or W4_FINAL.
