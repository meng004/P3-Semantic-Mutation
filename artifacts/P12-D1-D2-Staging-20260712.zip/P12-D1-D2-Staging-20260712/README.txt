P12 D1/D2 staging handoff package
Generated: 2026-07-12

Each directory contains the corpus archive and its required companion files:
  D1/d1-candidates.tar.zst
  D1/d1-candidates.manifest.json
  D1/d1-handoff.json
  D2/d2-candidates.tar.zst
  D2/d2-candidates.manifest.json
  D2/d2-handoff.json

Verify all files before provisioning them to P12:
  shasum -a 256 -c SHA256SUMS.txt

D1 is development/portfolio-construction evidence only. It is not D2-level
paired-revision real-defect evidence. D2 remains sealed staging input; this
package does not authorize opening D2 or running S1/S2.
